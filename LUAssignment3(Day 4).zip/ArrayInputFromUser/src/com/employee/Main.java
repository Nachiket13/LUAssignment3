package com.employee;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	int arrray[]=new int[5];
	int sum=0;

        System.out.println("Enter the values: ");
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<arrray.length;i++){
           arrray[i]= sc.nextInt();
        }
        for(int i=0;i<arrray.length;i++){
           sum=sum+arrray[i];
        }
        System.out.println("Sum of array elements is: "+sum);
    }
}
