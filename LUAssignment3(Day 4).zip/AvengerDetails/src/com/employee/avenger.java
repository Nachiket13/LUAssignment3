package com.employee;

import java.util.Scanner;

public class avenger {
    String name,power,weapon,planet;
    int age;

    Scanner sc = new Scanner(System.in);


    public void getDetails(){
        System.out.println("Enter The Avenger Name: ");
        name= sc.nextLine();
        System.out.println("Enter The Age of "+name+": ");
        age=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the Power of"+name+"is: ");
        power=sc.nextLine();
        System.out.println("Enter The Weapon of"+name+"is: ");
        weapon=sc.nextLine();
        System.out.println("Enter The Planet of"+name+"is: ");
        planet=sc.nextLine();
    }
    public void displayDetails(){
        System.out.println("The avenger name is: "+name);
        System.out.println("The age of avenger is: "+age);
        System.out.println("The avenger name is: "+power);
        System.out.println("The avenger name is: "+weapon);
        System.out.println("The avenger name is: "+planet);
    }

}
