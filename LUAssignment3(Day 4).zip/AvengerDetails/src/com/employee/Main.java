package com.employee;

public class Main {

    public static void main(String[] args) {
        // write your code here
        avenger obj1[] = new avenger[3];

        //Creating objects
        for (int i = 0; i < 3; i++) {
            obj1[i] = new avenger();
        }
        //get details
        for (int i = 0; i < 3; i++) {
            obj1[i].getDetails();
        }
        //print details
        for (int i = 0; i < 3; i++) {
            obj1[i].displayDetails();
        }
    }
}
